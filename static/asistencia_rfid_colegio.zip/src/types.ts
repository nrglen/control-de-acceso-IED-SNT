export interface Estudiante {
  id: number;
  codigo?: string | null;
  uid: string;
  nombre: string;
  grado: string;
  correo?: string | null;
  acudiente_nombre?: string | null;
  acudiente_contacto?: string | null;
  acudiente_correo?: string | null;
  foto?: string | null;
}

export interface ClaseHorario {
  id?: number;
  grado: string;
  salon: string;
  asignatura: string;
  profesor: string;
  hora_ingreso: string; // ej: "07:00"
}

export interface Asistencia {
  id: number;
  estudiante_id: number;
  codigo?: string | null;
  nombre: string;
  grado: string;
  correo?: string | null;
  acudiente_nombre?: string | null;
  acudiente_contacto?: string | null;
  acudiente_correo?: string | null;
  foto?: string | null;
  uid: string;
  salon: string;
  asignatura?: string | null;
  profesor?: string | null;
  hora_programada?: string | null;
  minutos_retraso?: number;
  metodo?: 'rfid' | 'manual';
  observacion?: string | null;
  fecha: string;
  hora: string;
}

export interface Lectura {
  id: number;
  uid: string;
  estudiante_id?: number | null;
  codigo?: string | null;
  nombre?: string | null;
  grado?: string | null;
  foto?: string | null;
  acudiente_nombre?: string | null;
  acudiente_contacto?: string | null;
  acudiente_correo?: string | null;
  salon: string;
  asignatura?: string | null;
  profesor?: string | null;
  minutos_retraso?: number;
  metodo?: string;
  estado: 'asistencia_registrada' | 'ya_registrada_hoy' | 'tarjeta_no_registrada' | 'tarjeta_capturada' | 'tarjeta_ya_asignada' | string;
  fecha_hora: string;
}

export interface ModoInfo {
  modo: 'asistencia' | 'registro';
  segundos_restantes: number;
}

export interface SystemStats {
  totalEstudiantes: number;
  asistenciasHoy: number;
  totalLecturasHoy: number;
  fecha: string;
}

export interface EmailConfig {
  smtp_host: string;
  smtp_port: number;
  smtp_secure: boolean;
  smtp_user: string;
  smtp_pass: string;
  sender_name: string;
  sender_email: string;
  auto_notify_scan: boolean;
  notify_on_tardy_only: boolean;
  configured?: boolean;
}

export interface EmailLog {
  id: number;
  estudiante_nombre: string;
  acudiente_correo: string;
  asunto: string;
  estado: 'enviado' | 'fallido' | 'simulado';
  fecha_hora: string;
  detalles?: string;
}
