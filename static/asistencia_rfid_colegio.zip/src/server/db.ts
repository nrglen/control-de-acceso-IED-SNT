import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

let db: Database;
const DB_PATH = path.join(process.cwd(), 'asistencia.db');

export const HORA_OFICIAL_ENTRADA = '08:30';
export const HORA_LIMITE_PUNTUALIDAD = '08:40';
export const GRADO_OFICIAL = '6° - 1';
export const SALON_OFICIAL = 'Salón de Informática';
export const ASIGNATURA_OFICIAL = 'Informática y Tecnología';

export interface Estudiante {
  id: number;
  codigo?: string | null;
  uid: string;
  nombre: string;
  grado: string;
  correo?: string | null;
  acudiente_nombre?: string | null;
  acudiente_contacto?: string | null;
  acudiente_correo?: string | null;
  foto?: string | null;
}

export interface ClaseHorario {
  id?: number;
  grado: string;
  salon: string;
  asignatura: string;
  profesor: string;
  hora_ingreso: string;
}

export interface Asistencia {
  id: number;
  estudiante_id: number;
  codigo?: string | null;
  nombre?: string;
  grado?: string;
  correo?: string | null;
  acudiente_nombre?: string | null;
  acudiente_contacto?: string | null;
  acudiente_correo?: string | null;
  foto?: string | null;
  uid?: string;
  salon: string;
  asignatura?: string | null;
  profesor?: string | null;
  hora_programada?: string | null;
  minutos_retraso?: number;
  metodo?: 'rfid' | 'manual';
  observacion?: string | null;
  fecha: string;
  hora: string;
}

export interface Lectura {
  id: number;
  uid: string;
  estudiante_id?: number | null;
  codigo?: string | null;
  nombre?: string | null;
  grado?: string | null;
  correo?: string | null;
  acudiente_nombre?: string | null;
  acudiente_contacto?: string | null;
  acudiente_correo?: string | null;
  foto?: string | null;
  salon: string;
  asignatura?: string | null;
  profesor?: string | null;
  hora_programada?: string | null;
  minutos_retraso?: number;
  metodo?: string;
  estado: string;
  fecha_hora: string;
}

export async function initDatabase() {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    try {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } catch (err) {
      console.error('Error loading asistencia.db, creating new database:', err);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  // Schema creation
  db.run(`
    CREATE TABLE IF NOT EXISTS config (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS estudiantes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo TEXT,
      uid TEXT UNIQUE NOT NULL,
      nombre TEXT NOT NULL,
      grado TEXT NOT NULL DEFAULT '6° - 1',
      correo TEXT,
      acudiente_nombre TEXT,
      acudiente_contacto TEXT,
      acudiente_correo TEXT,
      foto TEXT
    );

    CREATE TABLE IF NOT EXISTS email_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      smtp_host TEXT DEFAULT 'smtp.gmail.com',
      smtp_port INTEGER DEFAULT 587,
      smtp_secure INTEGER DEFAULT 0,
      smtp_user TEXT DEFAULT '',
      smtp_pass TEXT DEFAULT '',
      sender_name TEXT DEFAULT 'Colegio San Nicolás de Tolentino',
      sender_email TEXT DEFAULT '',
      auto_notify_scan INTEGER DEFAULT 1,
      notify_on_tardy_only INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS email_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      estudiante_nombre TEXT NOT NULL,
      acudiente_correo TEXT NOT NULL,
      asunto TEXT NOT NULL,
      estado TEXT NOT NULL,
      fecha_hora TEXT NOT NULL,
      detalles TEXT
    );

    CREATE TABLE IF NOT EXISTS clases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      grado TEXT NOT NULL,
      salon TEXT NOT NULL,
      asignatura TEXT NOT NULL,
      profesor TEXT NOT NULL,
      hora_ingreso TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS asistencias (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      estudiante_id INTEGER NOT NULL,
      salon TEXT NOT NULL,
      asignatura TEXT,
      profesor TEXT,
      hora_programada TEXT,
      minutos_retraso INTEGER DEFAULT 0,
      metodo TEXT DEFAULT 'rfid',
      observacion TEXT,
      fecha TEXT NOT NULL,
      hora TEXT NOT NULL,
      FOREIGN KEY (estudiante_id) REFERENCES estudiantes (id)
    );

    CREATE TABLE IF NOT EXISTS lecturas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uid TEXT NOT NULL,
      estudiante_id INTEGER,
      salon TEXT NOT NULL,
      asignatura TEXT,
      profesor TEXT,
      hora_programada TEXT,
      minutos_retraso INTEGER DEFAULT 0,
      metodo TEXT DEFAULT 'rfid',
      estado TEXT NOT NULL,
      fecha_hora TEXT NOT NULL
    );
  `);

  // Safe migrations
  try { db.run("ALTER TABLE estudiantes ADD COLUMN codigo TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE estudiantes ADD COLUMN correo TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE estudiantes ADD COLUMN acudiente_nombre TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE estudiantes ADD COLUMN acudiente_contacto TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE estudiantes ADD COLUMN acudiente_correo TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE asistencias ADD COLUMN asignatura TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE asistencias ADD COLUMN profesor TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE asistencias ADD COLUMN hora_programada TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE asistencias ADD COLUMN minutos_retraso INTEGER DEFAULT 0;"); } catch (e) {}
  try { db.run("ALTER TABLE asistencias ADD COLUMN metodo TEXT DEFAULT 'rfid';"); } catch (e) {}
  try { db.run("ALTER TABLE asistencias ADD COLUMN observacion TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE lecturas ADD COLUMN asignatura TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE lecturas ADD COLUMN profesor TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE lecturas ADD COLUMN hora_programada TEXT;"); } catch (e) {}
  try { db.run("ALTER TABLE lecturas ADD COLUMN minutos_retraso INTEGER DEFAULT 0;"); } catch (e) {}
  try { db.run("ALTER TABLE lecturas ADD COLUMN metodo TEXT DEFAULT 'rfid';"); } catch (e) {}

  // Populate sample guardian emails if null
  try {
    db.run("UPDATE estudiantes SET acudiente_correo = 'patricia.reyes.mendoza@gmail.com' WHERE id = 1 AND (acudiente_correo IS NULL OR acudiente_correo = '');");
    db.run("UPDATE estudiantes SET acudiente_correo = 'roberto.mendoza.soler@gmail.com' WHERE id = 2 AND (acudiente_correo IS NULL OR acudiente_correo = '');");
    db.run("UPDATE estudiantes SET acudiente_correo = 'elena.pena.vargas@gmail.com' WHERE id = 3 AND (acudiente_correo IS NULL OR acudiente_correo = '');");
    db.run("UPDATE estudiantes SET acudiente_correo = 'jorge.silva.duarte@gmail.com' WHERE id = 4 AND (acudiente_correo IS NULL OR acudiente_correo = '');");
    db.run("UPDATE estudiantes SET acudiente_correo = 'carmen.castillo.romero@gmail.com' WHERE id = 5 AND (acudiente_correo IS NULL OR acudiente_correo = '');");
  } catch (e) {}

  // Initialize email config table if empty
  try {
    const emailCfg = queryOne('SELECT id, smtp_user FROM email_config WHERE id = 1');
    if (!emailCfg) {
      run(`INSERT INTO email_config (id, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_pass, sender_name, sender_email, auto_notify_scan, notify_on_tardy_only)
           VALUES (1, 'smtp.gmail.com', 587, 0, 'notificaciones.sannicolas@gmail.com', 'sannicolas2026demo', 'I.E. San Nicolás de Tolentino', 'notificaciones.sannicolas@gmail.com', 1, 0)`);
    } else if (!emailCfg.smtp_user) {
      run(`UPDATE email_config SET 
           smtp_user = 'notificaciones.sannicolas@gmail.com',
           smtp_pass = 'sannicolas2026demo',
           sender_name = 'I.E. San Nicolás de Tolentino',
           sender_email = 'notificaciones.sannicolas@gmail.com'
           WHERE id = 1`);
    }
  } catch (e) {}

  // Update existing students to grade 6° - 1 if desired
  try {
    db.run("UPDATE estudiantes SET grado = '6° - 1' WHERE grado != '6° - 1';");
  } catch (e) {}

  // Ensure default class schedule for 6° - 1 in Salón de Informática
  const defaultClass = queryOne('SELECT id FROM clases WHERE grado = ? AND salon = ?', [GRADO_OFICIAL, SALON_OFICIAL]);
  if (!defaultClass) {
    run(
      'INSERT INTO clases (grado, salon, asignatura, profesor, hora_ingreso) VALUES (?, ?, ?, ?, ?)',
      [GRADO_OFICIAL, SALON_OFICIAL, ASIGNATURA_OFICIAL, 'Prof. Roberto Gómez', HORA_OFICIAL_ENTRADA]
    );
  }

  // Seed default students if empty
  const countRow = queryOne('SELECT COUNT(*) as count FROM estudiantes');
  if (countRow && countRow.count === 0) {
    const defaultStudents = [
      {
        uid: '8B6FD934',
        codigo: 'EST-601-001',
        nombre: 'Sofía Martínez Reyes',
        grado: '6° - 1',
        correo: 'sofia.martinez@sannicolas.edu.co',
        acudiente_nombre: 'Patricia Reyes Mendoza',
        acudiente_contacto: '+57 315 889 4421',
        acudiente_correo: 'patricia.reyes.mendoza@gmail.com',
        foto: null
      },
      {
        uid: 'B21890EF',
        codigo: 'EST-601-002',
        nombre: 'Carlos Daniel Mendoza',
        grado: '6° - 1',
        correo: 'carlos.mendoza@sannicolas.edu.co',
        acudiente_nombre: 'Roberto Mendoza Soler',
        acudiente_contacto: '+57 311 445 7712',
        acudiente_correo: 'roberto.mendoza.soler@gmail.com',
        foto: null
      },
      {
        uid: 'C77410A1',
        codigo: 'EST-601-003',
        nombre: 'Valentina Gómez Peña',
        grado: '6° - 1',
        correo: 'valentina.gomez@sannicolas.edu.co',
        acudiente_nombre: 'Elena Peña Vargas',
        acudiente_contacto: '+57 320 667 8901',
        acudiente_correo: 'elena.pena.vargas@gmail.com',
        foto: null
      },
      {
        uid: 'D59021B3',
        codigo: 'EST-601-004',
        nombre: 'Mateo Alejandro Silva',
        grado: '6° - 1',
        correo: 'mateo.silva@sannicolas.edu.co',
        acudiente_nombre: 'Jorge Silva Duarte',
        acudiente_contacto: '+57 300 223 9988',
        acudiente_correo: 'jorge.silva.duarte@gmail.com',
        foto: null
      },
      {
        uid: 'E821034A',
        codigo: 'EST-601-005',
        nombre: 'Lucía Fernández Castillo',
        grado: '6° - 1',
        correo: 'lucia.fernandez@sannicolas.edu.co',
        acudiente_nombre: 'Carmen Castillo Romero',
        acudiente_contacto: '+57 318 554 1123',
        acudiente_correo: 'carmen.castillo.romero@gmail.com',
        foto: null
      }
    ];

    for (const est of defaultStudents) {
      run(
        `INSERT INTO estudiantes (codigo, uid, nombre, grado, correo, acudiente_nombre, acudiente_contacto, acudiente_correo, foto) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [est.codigo, est.uid, est.nombre, est.grado, est.correo, est.acudiente_nombre, est.acudiente_contacto, est.acudiente_correo, est.foto]
      );
    }
  }

  saveDb();
  return db;
}

export function saveDb() {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (err) {
    console.error('Error saving database to file:', err);
  }
}

export function queryAll<T = any>(sql: string, params: any[] = []): T[] {
  if (!db) throw new Error('Database not initialized');
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    const results: T[] = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject() as unknown as T);
    }
    return results;
  } finally {
    stmt.free();
  }
}

export function queryOne<T = any>(sql: string, params: any[] = []): T | null {
  const all = queryAll<T>(sql, params);
  return all.length > 0 ? all[0] : null;
}

export function run(sql: string, params: any[] = []): { changes: number; lastInsertRowid: number } {
  if (!db) throw new Error('Database not initialized');
  db.run(sql, params);
  
  const row = queryOne('SELECT last_insert_rowid() as id');
  const lastInsertRowid = row ? Number(row.id) : 0;
  
  saveDb();
  return { changes: 1, lastInsertRowid };
}

export function normalizeUid(rawUid: string | null | undefined): string {
  if (!rawUid) return '';
  return rawUid.toString().replace(/[:\s]/g, '').trim().toUpperCase();
}

export function getLocalDateTime() {
  const d = new Date();
  const pad = (n: number) => n.toString().padStart(2, '0');
  const fecha = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const hora = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  const fecha_hora = `${fecha} ${hora}`;
  return { fecha, hora, fecha_hora };
}

/**
 * Regla Grado 6° - 1 (Salón de Informática):
 * Hora oficial de entrada: 08:30 AM
 * Tolerancia: Hasta las 08:40 AM se toma como Puntual.
 * Luego de las 08:40 AM (> 08:40:00) se toma como Entrada Tarde (retraso).
 * 
 * @param horaLlegada ej: "08:35:12" o "08:45:00"
 * @returns { esTarde: boolean, minutosRetraso: number, estado: 'Puntual' | 'Tarde' }
 */
export function calcularPuntualidad(
  horaLlegada: string, 
  horaOficial = HORA_OFICIAL_ENTRADA, 
  horaLimite = HORA_LIMITE_PUNTUALIDAD
) {
  if (!horaLlegada) return { esTarde: false, minutosRetraso: 0, estado: 'Puntual' };
  try {
    const [hl, ml, sl = 0] = horaLlegada.split(':').map(Number);
    const [ho, mo] = horaOficial.split(':').map(Number);
    const [hx, mx] = horaLimite.split(':').map(Number);

    const segsLlegada = hl * 3600 + ml * 60 + sl;
    const segsOficial = ho * 3600 + mo * 60;
    const segsLimite = hx * 3600 + mx * 60;

    // Si llega a las 08:40 o antes -> PUNTUAL
    if (segsLlegada <= segsLimite) {
      return { esTarde: false, minutosRetraso: 0, estado: 'Puntual' };
    } else {
      // Después de 08:40 -> TARDE
      const minutosRetraso = Math.ceil((segsLlegada - segsOficial) / 60);
      return { esTarde: true, minutosRetraso, estado: 'Tarde' };
    }
  } catch {
    return { esTarde: false, minutosRetraso: 0, estado: 'Puntual' };
  }
}

export function calcularRetraso(horaLlegada: string, horaProgramada: string): number {
  return calcularPuntualidad(horaLlegada, horaProgramada).minutosRetraso;
}
